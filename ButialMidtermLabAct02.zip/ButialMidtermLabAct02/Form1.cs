﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButialMidtermLabAct02
{
    public partial class Form1 : Form
    {
        public List<char> operandStack;
        public Stack<char> operatorStack;
        List<char> origStack = new List<char>();
        Dictionary<char, int> sortedStack = new Dictionary<char, int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void bpost_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InfixToPostFix(textBox1.Text);
                textBox2.Text = output;
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;

            }

        }

        private void bpre_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InfixToPreFix(textBox1.Text);
                textBox2.Text = output;
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }
        }
        private string InfixToPostFix(string source)
        {
            string output = "";
            operandStack = new List<char>();
            operatorStack = new Stack<char>();
            origStack = new List<char>();
            sortedStack = new Dictionary<char, int>();

            foreach (char node in source) {
                if (char.IsNumber(node))
                {
                    output += node;

                    if (operatorStack.Count > 0) {

                        int level = GetPrecedence(operatorStack.First());
                        if (level >= 2)
                        {
                            output += operatorStack.Pop(); ;

                        }
                    }
                }
                else
                {
                    if (GetPrecedence(node) == 0)
                    {
                        throw new Exception("Your expression has an invalid operator ");
                    }
                    if (GetPrecedence(node) == 4)
                    {
                        throw new Exception("Parenthesis are not yet Supported! ");
                    }
                    operatorStack.Push(node);
                }

            }
            while (operatorStack.Count > 0)
            {
                output += operatorStack.Pop();
            }
            return output;
        }

        private string InfixToPreFix(string source)
        {
            string revsrc = string.Join("", source.Reverse());
            string output = InfixToPostFix(revsrc);
            return string.Join("", output.Reverse());


        }
        private int GetPrecedence(char oprtor)
        {
            switch (oprtor)
            {
                case '(':
                case ')':
                    return 4;
                    break;

                case '^':
                    return 3;
                    break;

                case '*':
                case '/':
                    return 2;
                    break;

                case '-':
                case '+':
                    return 1;
                    break;

                default:
                    return 0;
                    break;
            }
        }
        
        private Stack<char> SortStack()
        {
            origStack = operatorStack.ToList();
            foreach (char node in origStack)
            {
                sortedStack.Add(node, GetPrecedence(node));
            }
            Dictionary<char, int> sortedDict = sortedStack.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            Stack<char> newSortedStack = new Stack<char>();
            foreach (char node in sortedDict.Keys)
            {
                newSortedStack.Push(node);
            }
            return newSortedStack;
        }

        }
    }

   




